<?php
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Inscription participants</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        #video,
        #preview {
            max-width: 100%;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <span class="navbar-brand">Inscription participants</span>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header">
                        <h1 class="h5 mb-0">Inscription à partir d’un document d’identité</h1>
                    </div>
                    <div class="card-body">
                        <h2 class="h6 mb-3">1. Choisir le document</h2>
                        <form id="uploadForm" action="process_document.php" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Type de document</label>
                                <select name="document_type" class="form-select" required>
                                    <option value="cin">Carte nationale</option>
                                    <option value="passport">Passeport</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Importer une image du document</label>
                                <input type="file" name="document_image" accept="image/*" class="form-control">
                            </div>

                            <input type="hidden" name="camera_image" id="camera_image">

                            <div class="text-center my-3">
                                <span class="text-muted">ou</span>
                            </div>

                            <div class="d-flex flex-wrap gap-2 mb-3">
                                <button type="button" id="startCamera" class="btn btn-outline-primary flex-fill">Utiliser la caméra</button>
                                <button type="button" id="capturePhoto" class="btn btn-primary flex-fill" disabled>Capturer</button>
                            </div>

                            <div class="mb-3">
                                <video id="video" autoplay playsinline class="w-100 d-none"></video>
                                <canvas id="canvas" class="d-none"></canvas>
                                <img id="preview" alt="Aperçu de l’image" class="img-fluid d-none mt-2">
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-success btn-lg">Extraire les informations</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const startCameraButton = document.getElementById('startCamera');
        const capturePhotoButton = document.getElementById('capturePhoto');
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const preview = document.getElementById('preview');
        const cameraImageInput = document.getElementById('camera_image');

        let stream = null;

        startCameraButton.addEventListener('click', async () => {
            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    video: true
                });
                video.srcObject = stream;
                video.classList.remove('d-none');
                capturePhotoButton.disabled = false;
            } catch (error) {
                alert('Impossible d’accéder à la caméra: ' + error.message);
            }
        });

        capturePhotoButton.addEventListener('click', () => {
            if (!stream) {
                return;
            }

            const trackSettings = stream.getVideoTracks()[0].getSettings();
            const width = trackSettings.width || 640;
            const height = trackSettings.height || 480;

            canvas.width = width;
            canvas.height = height;

            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, width, height);

            const dataUrl = canvas.toDataURL('image/png');
            preview.src = dataUrl;
            preview.style.display = 'block';

            cameraImageInput.value = dataUrl;

            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            video.classList.add('d-none');
            capturePhotoButton.disabled = true;
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>