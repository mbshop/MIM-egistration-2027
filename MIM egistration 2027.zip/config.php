<?php

const DB_DSN = 'mysql:host=localhost;dbname=participants_db;charset=utf8mb4';
const DB_USER = 'root';
const DB_PASSWORD = 'password';

const GOOGLE_SERVICE_ACCOUNT_JSON = __DIR__ . '/credentials.json';
const GOOGLE_SHEETS_SPREADSHEET_ID = 'VOTRE_SPREADSHEET_ID_ICI';
const GOOGLE_SHEETS_RANGE = 'Feuille1!A2:G';

const TESSERACT_PATH = 'tesseract';
const TESSERACT_LANGUAGES = 'eng+fra';

function getPdo(): PDO
{
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    return new PDO(DB_DSN, DB_USER, DB_PASSWORD, $options);
}
